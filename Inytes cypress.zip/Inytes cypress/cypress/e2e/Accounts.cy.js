describe('Accounts', () => {
    it('Submit Profile', () => {
      cy.visit('https://dev.inytes.com/account/#fndtn-profile-tab')
  
  
  
    })
  })