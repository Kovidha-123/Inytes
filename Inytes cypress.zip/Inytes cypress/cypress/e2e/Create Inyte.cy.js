describe('Login after selecting the Invitation card', () => {
  it('passes', () => {
    cy.visit('https://inytes.com/')

    cy.contains('Create Invitation').click()

    cy.url().should('include', '/invitations')

    cy.xpath('//a[@data-cat="occasions" and text()="Pooja"]').click();
    cy.wait(5000)
    cy.xpath('//img[@class="thumb-image" and @alt="Gateway to Vishnuloka"]').click()
  //     .should('have.attr', 'src', 'https://cdn.inytes.com/images/designs/thumbs/grihapravesh-pooja-invitation-185-opt1.png')
  //     .and('have.attr', 'alt', 'Gateway to Vishnuloka').click();
  // cy.wait(5000)

    // cy.xpath('//section[@class="cd-gallery filter-is-visible"]//ul//li[1]').click({ multiple: true })

    // cy.xpath('(//img[@class=thumb-image])[1]').click()

    cy.wait(5000)

     cy.xpath("//a[text()='Personalize']").should('exist')
     cy.xpath("//a[text()='Personalize']").click()

     cy.url().should('include', '/login/')

     cy.get('[id=user_login]').type("kovidha@codepeers.com")

     cy.get('[id=user_password]').type("Inytes12#")

     cy.get('[id=email-login]').click()

    // cy.wait(5000)
    //  cy.url().should('https://www.inytes.com/')


  })
})